import SwiftUI

struct ContentView: View {
    @State private var rollResult = ""
    @State private var diceValues = [1, 1] // Initialize with any values as they'll be updated on roll
    
    var body: some View {
        VStack {
            Text(rollResult)
                .padding()
            
            HStack {
                ForEach(diceValues, id: \.self) { value in
                    Image("dice\(value)")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 100, height: 100)
                }
            }
            .padding()
            
            Button("Roll Dice") {
                rollDice()
            }
            .padding()
        }
        .padding()
    }
    
    func rollDice() {
        let roll1 = Int.random(in: 1...6)
        let roll2 = Int.random(in: 1...6)
        
        diceValues = [roll1, roll2]
        
        let total = roll1 + roll2
        rollResult = "You rolled: \(roll1) and \(roll2)\nTotal: \(total)"
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}




